package FelipeGabrielS_rodrigues;

import java.sql.SQLException;
import java.util.ArrayList;

public class Bar implements InterfaceBar{
    ArrayList<Cliente> lista_de_clientes ;
    CardapioDAO cardapio = new CardapioDAO();

    public Bar() throws SQLException{
       lista_de_clientes = new ArrayList<>();
    }

    public void abrirConta(int numConta, int cpf, String nomeCliente) throws ContaAberta, ContaInexistente, DadosInvalidos{
        if(numConta <= 0 || cpf <= 0 || nomeCliente == null || nomeCliente.isEmpty() ){
            throw new DadosInvalidos("Dado(s) inválidos");
        }
        if(pesquisarCliente(numConta) != null ){
            throw new ContaAberta("conta ja aberta");
        }

        Cliente aux = new Cliente(numConta,cpf,nomeCliente);
        lista_de_clientes.add(aux);

    }

    public void addPedido(int numConta, int numItem, int quant) throws ContaFechada, ContaInexistente, ItemInexistente, DadosInvalidos,SQLException{
        if(numConta <= 0 || numItem <= 0 || quant <= 0){
            throw new DadosInvalidos("Dado(s) inválidos");
            }
        Item it = pesquisarItem(numItem);

        if(it == null){
            throw new ItemInexistente("o item pedido não existe");
        }

        Cliente aux = pesquisarCliente(numConta);

        if( aux == null){
            throw new ContaInexistente("conta não encontrada");
        }

        if(!aux.isContaaberta()){
            throw new ContaFechada("conta ja foi fechada");
        }

        String Monext = "Item: "+it.getDesc()+", valor unitário: "+
                it.getValor() + ", valor total: "+it.getItemPrec(quant)+"\n";

        if (it instanceof Bebida){
            aux.addped(it.getItemPrec(quant),1,Monext);
        } else if (it instanceof Comida) {
            aux.addped(it.getItemPrec(quant),2,Monext);
        }

    }

    public double valorDaConta(int numConta) throws ContaInexistente{

        Cliente aux = pesquisarCliente(numConta);
        if(aux == null){
            throw new ContaInexistente("conta não encontrada");
        }

        return aux.getConta();
    }

    public double fecharConta(int numConta) throws ContaInexistente{
        Cliente aux  = pesquisarCliente(numConta);

        if(aux == null){
            throw new ContaInexistente("conta não encontrada");
        }

        String MontAux = " Valor final:   Bebidas: " + aux.getbebi() +" +10% sobre bebidas , Comidas: "+
        aux.getCom()+" +15% sobre a Comida , = " + aux.getConta() +"\n";

        double valor = aux.getConta();
        aux.setContaaberta(false);
        aux.addInConsumo(MontAux);
        return valor;
    }

    public void addCardapio(int nu, String n, double x, int tp) throws ItemJaCadastrado, DadosInvalidos, SQLException {
        if(nu <= 0 || x <= 0 ||  tp <= 0 || n == null || n.isEmpty()){
           throw new DadosInvalidos("Dado(s) inválidos");
        }

        cardapio.addCardDAO(nu, n, x, tp);
    }

    public void registrarPagamento(int numConta, double val) throws PagamentoMaior, ContaInexistente, DadosInvalidos{
        if(numConta <= 0 || val <= 0){
            throw new DadosInvalidos("Dado(s) inválidos");
        }

        Cliente aux  = pesquisarCliente(numConta);

        if(aux == null){
            throw new ContaInexistente("conta não encontrada");
        }

        double valor = aux.getConta();

        if(val > valor){
            throw new PagamentoMaior("Pagamento maior que o em Conta");
        }

        aux.setPagamento(val);

    }

    public ArrayList<Consumo> extratoDeConta(int numConta) throws ContaInexistente{
        Cliente aux = pesquisarCliente(numConta);

        if(aux == null){
            throw new ContaInexistente("conta não encontrada");
        }

        return aux.getExtrato();
    }

    private Cliente pesquisarCliente(int num) {
        for (Cliente cliente : lista_de_clientes) {
            if (cliente.getNum() == num) {
                return cliente;
            }
        }
        return null;
    }

    private Item pesquisarItem(int num) throws SQLException,ItemInexistente{
        try{
            return cardapio.SearchCADAO(num);
        }catch (ItemInexistente e){
            return null;
        }
    }

    //função para usar nos testes
    public void RemoveAll() throws SQLException{
        cardapio.RemoveAll();
    }

    public void UpdateCardapio(int nu, String n, double x, int tp) throws  SQLException{
        cardapio.UpdateProd(nu, n, x, tp);
    }
}
