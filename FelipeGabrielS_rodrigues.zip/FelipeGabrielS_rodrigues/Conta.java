package FelipeGabrielS_rodrigues;

public class Conta { ;
    double bebida;
    double comida;
    double aux_pagamento = 0;
    double aux_final;

    public void addInConta(double valor,int tp){
        if(tp == 1){
          this.bebida += valor;
        }
        if(tp == 2){
            this.comida += valor;
        }
    }

    public double getBebida() {
        return bebida;
    }

    public double getComida() {
        return comida;
    }

    public double getContafinal() {
        aux_final = (bebida + (0.1 * bebida) + comida + (0.15 * comida)) - aux_pagamento;
        return aux_final;
    }

    public void setPagamento(double valor){
        this.aux_pagamento += valor;
    }
}
