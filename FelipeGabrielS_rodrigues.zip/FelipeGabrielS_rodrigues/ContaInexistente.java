package FelipeGabrielS_rodrigues;

public class ContaInexistente extends RuntimeException {
    public ContaInexistente(String message) {
        super(message);
    }
}
