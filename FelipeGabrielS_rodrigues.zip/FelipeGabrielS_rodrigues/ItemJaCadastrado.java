package FelipeGabrielS_rodrigues;

public class ItemJaCadastrado extends RuntimeException {
    public ItemJaCadastrado(String message) {
        super(message);
    }
}
