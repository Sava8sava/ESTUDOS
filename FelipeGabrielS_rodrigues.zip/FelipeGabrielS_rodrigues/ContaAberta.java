package FelipeGabrielS_rodrigues;

public class ContaAberta extends RuntimeException {
    public ContaAberta(String message) {
        super(message);
    }
}
