package FelipeGabrielS_rodrigues;

public class DadosInvalidos extends RuntimeException {
    public DadosInvalidos(String message) {
        super(message);
    }
}
