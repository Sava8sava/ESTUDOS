package FelipeGabrielS_rodrigues;

public class PagamentoMaior extends RuntimeException {
    public PagamentoMaior(String message) {
        super(message);
    }
}
