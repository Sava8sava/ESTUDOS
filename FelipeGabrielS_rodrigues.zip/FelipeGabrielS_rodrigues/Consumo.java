package FelipeGabrielS_rodrigues;


public class Consumo {
    String extrato ;

    public Consumo(String s){
        this.extrato = s;
    }

    public String getExtrato() {
        return extrato;
    }
}
