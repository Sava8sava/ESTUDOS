package FelipeGabrielS_rodrigues;

public class ContaFechada extends RuntimeException {
    public ContaFechada(String message) {
        super(message);
    }
}
