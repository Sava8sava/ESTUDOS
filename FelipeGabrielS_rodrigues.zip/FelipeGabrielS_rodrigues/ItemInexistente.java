package FelipeGabrielS_rodrigues;

public class ItemInexistente extends RuntimeException {
    public ItemInexistente(String message) {
        super(message);
    }
}
